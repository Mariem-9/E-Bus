#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>
#include<string.h>
typedef struct comptevoyageur voy;
 struct comptevoyageur{
	char nom[10];
	char prenom[10];
	int CIN;
	int phone;
	char mail[20];
	struct comptevoyageur* suivant;
};
typedef voy* liste; 

typedef struct reservation res; 
 struct reservation{                     
	int CIN;//CIN du reservateur
	char desaller[20];//destination
	char desdepart[20];//place de depart
	int numbus;//num�ro du bus
	int resj;int resm;int resa;
	int periode;//nbr de jour de reservation
	struct reservation* suivant; //creation du liste chain�� de reservation
};
typedef res* liste1;                 

typedef struct bus bus;
struct bus{
	int numbus;
	int dispo;
	struct bus* suivant;
};
typedef struct bus* liste2;

int nbrlignes(FILE* f){
	char ch[256];
	int N=0;
        f=fopen("./projetbus.txt","r");
        while ((fgets (ch,256,f)) != NULL){
         	N++;
        }
        fclose(f);
        //printf("N=%d\n",N);
        return N;
}
int nbrlignes1(FILE* f){
	char ch[256];
	int N=0;//nbr action permise
        f=fopen("./listeactionprojetbus.txt","r");
        while ((fgets (ch,256,f)) != NULL){
         	N++;
        }
        fclose(f);
        //printf("N=%d\n",N);
        return N;
}
int nbrlignes2(FILE* f){
	char ch[256];
	int N=0;//nbr des option a modifier
        f=fopen("./modifierresprojetbus.txt","r");
        while ((fgets (ch,256,f)) != NULL){
         	N++;
        }
        fclose(f);
        //printf("N=%d\n",N);
        return N;
}
int nbrlignes3(FILE* f){
	char ch[256];
	int N=0;//nbr des option a modifier
        f=fopen("./administrateurprojetbus.txt","r");
        while ((fgets (ch,256,f)) != NULL){
         	N++;
        }
        fclose(f);
        //printf("N=%d\n",N);
        return N;
}
void afficheradministrateuraction(FILE* f,int i){
	char ch[256];
	f=fopen("./administrateurprojetbus.txt","r");
    if(f==NULL){
        printf("fichier introuvable");
    }
    
    for(int j=0;j<i;j++){
        fgets (ch,256,f);
        printf("%s",ch);
    }
    fclose(f);
    //printf("ok\n");
}
void afficherdescriptionbus(FILE* f,int i){
	char ch[256];
	f=fopen("./projetbus.txt","r");
    if(f==NULL){
        printf("fichier introuvable");
    }
    
    for(int j=0;j<i;j++){
        fgets (ch,256,f);
        printf("%s",ch);
    }
    fclose(f);
    //printf("ok\n");
}
void afficherlisteaction(FILE* f,int i){
	char ch[256];
	f=fopen("./listeactionprojetbus.txt","r");
    if(f==NULL){
        printf("fichier introuvable");
    }
    
    for(int j=0;j<i;j++){
        fgets (ch,256,f);
        printf("%s",ch);
    }
    fclose(f);
    //printf("ok\n");
}
void affichermodifresoption(FILE* f,int i){
	char ch[256];
	f=fopen("./modifierresprojetbus.txt","r");
    if(f==NULL){
        printf("fichier introuvable");
    }
    
    for(int j=0;j<i;j++){
        fgets (ch,256,f);
        printf("%s",ch);
    }
    fclose(f);
    //printf("ok\n");
}
void administrateur(FILE* f,int nblignes){ 
	//je suis un administrateur
	FILE* f3;
	int nblignes3,v2,s;
	int N=nblignes-3;
	nblignes3=nbrlignes3(f3);
	afficheradministrateuraction(f3,nblignes3);
    		v2=0;//v2:num�ro du choix
    		while(v2!=5){
    	        printf("choix numero: ");
    	        scanf("%d",&v2);
    			if(v2==1){
    				printf("liste des bus : \n");
    				afficherdescriptionbus(f,nblignes);
    				printf("------------------------------------------------------------------------------------------\n");
				}
				if(v2==2){
					//ajout d'un bus
					FILE* f4;
					char ch[256],a[256],b[256],c[256],d[256],e[256];
                	f4=fopen("./projetbus.txt","a");
                    if(f4==NULL){
                    	printf("fichier introuvable");
                    }
                    printf("details du bus ajoutee: \n");
                    sprintf(a,"%d",N+1);
                    fflush(stdin);
                    printf("Fuel Type: ");gets(b);
                    printf("Color: ");gets(c);
                    printf("Number Of Seat: ");gets(d);
                    printf("Prix Par Jour: ");gets(e);
                    strcpy(ch,"|  ");strcat(ch,a);strcat(ch,"   |   ");strcat(ch,b);strcat(ch,"         |     ");strcat(ch,c);strcat(ch,"         |            ");
					strcat(ch,d);strcat(ch,"            |        ");strcat(ch,e);strcat(ch,"D     |\n");
					fputs(ch,f4);
                    fclose(f4);
                    nblignes=nblignes+1;
			    }
			    if(v2==3){
			    	//supprimer un bus
			    	printf("Numero du bus � supprimer: ");scanf("%d",&s);
			    	while(s>N){
			    		printf("choisir correctement le numero du bus ");
		                scanf(" %d",&s);
	                }
			    	s=s+3;
			    	FILE* f5;
			    	FILE* f6;
					char ch[256],ch1[5];
                	f5=fopen("./projetbus.txt","r");
                    if(f5==NULL){
                    	printf("fichier introuvable");
                    }
                    f6=fopen("./2.txt","w");
                    if(f6==NULL){
                    	printf("fichier introuvable");
                    }
                    for(int j=0;j<nblignes;j++){
                    	if(j==s-1){
                    		fgets (ch,256,f5);
                    		strcpy(ch,"|      |                 |                   |                          |                 |\n");
                    		fputs(ch,f6);
                    		
						}
						else{
							fgets (ch,256,f5);
							fputs(ch,f6);
						}
					} 
                    fclose(f6);fclose(f5);
                    remove("./projetbus.txt");
					rename("./2.txt","projetbus.txt");
				}
				if(v2==4){
					//modifier le prix d'un bus
					printf("Numero du bus � modifier: ");scanf("%d",&s);
					while(s>N){
			    		printf("choisir correctement le numero du bus ");
		                scanf(" %d",&s);
	                }
					s=s+3;
			    	char prix[10];printf("Nouveau prix: ");scanf("%s",&prix);strcat(prix,"D     |\n");
			    	FILE* f7;FILE* f8;char ch[256],ch1[82],ch2[256];
                	f7=fopen("./projetbus.txt","r");
                    if(f7==NULL){
                    	printf("fichier introuvable");
                    }
                    f8=fopen("./3.txt","w");
                    if(f8==NULL){
                    	printf("fichier introuvable");
                    }
                    for(int j=0;j<nblignes;j++){
                    	if(j==s-1){
                    		strcpy(fgets (ch,256,f7),fgets (ch1,82,f7));
                    	    strcat(ch,prix);
                    	    strcpy(ch2,ch);
                    		fputs(ch2,f8);
                    		
						}
						else{
							fgets (ch,256,f7);
							fputs(ch,f8);
						}
					} 
                    fclose(f7);fclose(f8);
                    remove("./projetbus.txt");
					rename("./3.txt","projetbus.txt");
					
				}
			}
}
//ajout t�te d'un nouveau compte voyageur
liste creationvoy(liste l){         
	liste p;
	p=(voy*)malloc(sizeof(voy));
	fflush(stdin);
	printf("\nNOM:");gets(p->nom);
	printf("PRENOM:");gets(p->prenom);
	printf("MAIL:");gets(p->mail);
	printf("CIN:");scanf(" %d",&(p->CIN));
	printf("PHONE:");scanf(" %d",&(p->phone));
	l=p;
	return l;
}
//affichage des comptes du voyageur 
void affichagecomptevoy(liste l){
	while(l!=NULL){
		printf("\nNOM:%s",l->nom);
		printf("\nPRENOM:%s",l->prenom);
		printf("\nMAIL:%s",l->mail);
		printf("\nCIN:%d",l->CIN);
		printf("\nPHONE:%d",l->phone);
		l=l->suivant;
	}
}
//ajout t�te d'un nouveau compte voyageur reservation
liste1 creationres(liste1 l1,int N){     
	liste1 q;
	q=(res*)malloc(sizeof(res));
	printf("\nCIN:");
	scanf(" %d",&(q->CIN));
	fflush(stdin);
	printf("place de depart:");gets(q->desdepart);
	printf("destination :");gets(q->desaller);
	printf("numero du bus:");scanf(" %d",&(q->numbus));
	while((q->numbus)>N){
		printf("choisir correctement le numero du bus ");
		scanf(" %d",&(q->numbus));
	}
	printf("Date de reservation:\n");
	printf("jj:");scanf(" %d",&(q->resj));
	while((q->resj)>31){
		printf("saisir correctement le numero du jour ");
		scanf(" %d",&(q->resj));
	}
	printf("mm:");scanf(" %d",&(q->resm));
	while((q->resm)>12){
		printf("saisir correctement le numero du mois ");
		scanf(" %d",&(q->resm));
	}
	printf("aaaa:");scanf(" %d",&(q->resa));
	fflush(stdin);
	printf("periode de reservation(nombre de jour):");scanf(" %d",&(q->periode));
	l1=q;
	return l1;
}
//affichage des comptes du voyageur reservation 
void affichagecompteres(liste1 l1){
	while(l1!=NULL){
		printf("\nCIN:%d",l1->CIN);
		printf("\ndesdepart:%s",l1->desdepart);
		printf("\ndesaller:%s",l1->desaller);
		printf("\nnumbus:%d",l1->numbus);
		printf("\ndate:%d/%d/%d",l1->resj,l1->resm,l1->resa);
		printf("\nPeriode:%d",l1->periode);
		l1=l1->suivant;
	}
}
//affichage du compte du personne X
void affichagecompteX(liste l){
	int aux,b;
    printf("CIN: ");scanf("%d",&aux);
    b=0;
    while(l!=NULL){
    	if((l->CIN)==aux){
    		printf("\nNOM:%s",l->nom);
		    printf("\nPRENOM:%s",l->prenom);
		    printf("\nMAIL:%s",l->mail);
		    printf("\nCIN:%d",l->CIN);
		    printf("\nPHONE:%d",l->phone);
		    printf("\n");
		    b=1;
		    break;
		    }
		l=l->suivant;
	}
	if(b!=1){
	    printf("vous n'avez pas un compte\n");
	} 
}
//modifier compte du personne X
void modifiercompteX(liste l){     
	int aux1,aux2,b=0;
    printf("CIN: ");
    scanf("%d",&aux1);
	while(l!=NULL){
		if((l->CIN)==aux1){
			b=1;
			printf("choix numero: ");
	        scanf("%d",&aux2);
    	    if(aux2==1){
    	    	printf("\nNOM:");
    	    	fflush(stdin);
				gets(l->nom);
			}
			if(aux2==2){
    	    	printf("\nPrenom: ");
    	    	fflush(stdin);
				gets(l->prenom);
					}
			if(aux2==3){
    	    	printf("\nMail: ");
    	    	fflush(stdin);
				gets(l->mail);
					}
			if(aux2==4){
				printf("\nPhone: ");
				scanf("%d",l->phone);
					}
			if(aux2==5){
				printf("compte modifiee ");
					}
		     	}
		    break;
		l=l->suivant;
		} 
	if(b!=1){
		printf("vous n'avez pas un compte\n");
		} 
		    
	}
//affichage du reservation du personne X
void affichagereservationX(liste1 l1){
	int aux,b;
    printf("CIN: ");scanf("%d",&aux);
    b=0;
    while(l1!=NULL){
    	if((l1->CIN)==aux){
    		printf("\nCIN:%d",l1->CIN);
		    printf("\ndesdepart:%s",l1->desdepart);
		    printf("\ndesaller:%s",l1->desaller);
		    printf("\nnumbus:%d",l1->numbus);
		    printf("\ndate:%d/%d/%d",l1->resj,l1->resm,l1->resa);
		    printf("\nPeriode:%d",l1->periode);
		    printf("\n");
		    b=1;
		    break;
		    }
		l1=l1->suivant;
	}
	if(b!=1){
	    printf("vous n'avez pas une reservation\n");
	} 
}
//modifier du reservation du personne X
void modifierres(liste1 l1){     
	int aux1,aux2,b=0;
    printf("CIN: ");
    scanf("%d",&aux1);
	while(l1!=NULL){
		if((l1->CIN)==aux1){
			b=1;
			printf("choix numero: ");
	        scanf("%d",&aux2);
    	    if(aux2==1){
    	    	printf("\ndesdepart:");
				scanf("%s",l1->desdepart);
			}
			if(aux2==2){
    	    	printf("\ndesaller: ");
				scanf("%s",l1->desaller);
					}
			if(aux2==3){
    	    	printf("\nnumbus: ");
				scanf("%d",l1->numbus);
					}
			if(aux2==4){
				printf("\njj:");scanf(" %d",l1->resj);
				printf("\nmm:");scanf(" %d",l1->resm);
				printf("\naaaa:");scanf(" %d",l1->resa);    	
					}
			if(aux2==5){
				printf("\nPeriode: ");
				scanf("%d",l1->periode);
					}
			if(aux2==6){
				printf("reservation modifiee ");
					}
		     	}
		    break;
		l1=l1->suivant;
		} 
	if(b!=1){
		printf("vous n'avez pas une reservation\n");
		} 
		    
	}
//affichage du structure bus
void affichagestructbus(liste2 l2){
	while(l2!=NULL){
		printf("\nnumbus:%d",l2->numbus);
		printf("\ndispo:%d",l2->dispo);
		l2=l2->suivant;
		printf("\n");
	}
}
void busdispo(int aux,liste2 l2,liste1 l1){ 
        while(l2!=NULL){
				if(aux==(l2->numbus)){
					if(l2->dispo==0){
					    printf("\n ____________________________________________________________________\n");
					    printf("\n|                      reservation reussi                            |\n");
				        printf("\n|     le %d/%d/%d vous avez reservee le bus numero %d pour %djours   |\n ",l1->resj,l1->resm,l1->resa,l1->numbus,l1->periode);
				        printf("\n|____________________________________________________________________|\n");
				        l2->dispo=1;
				        break;
		    	    }
		    	
		    	    else{
		    	    
		    	    	printf("Page5------------------------------------------------------------\n");
			        	printf("    Desole ,cette bus est deja reservee pour un autre voyageur\n");
				        break;	
			    	}
			    }
			    l2=l2->suivant;
		    }
		}

liste1 supprimerestete(liste1 l1){
    liste1 q;
	q=l1;
	l1=l1->suivant;
	free(q);
	return l1;
}
liste supprimercomptete(liste l){
    liste q;
	q=l;
	l=l->suivant;
	free(q);
	return l;
}
int main() {
	FILE* f;FILE* f1;FILE* f2;char ch[256];
    liste l; l=NULL;liste1 l1; l1=NULL;liste2 l2,r;l2=NULL;
    int PW,nblignes,nblignes1,nblignes2;int x1,x2,x3,x4,x5;
    nblignes=nbrlignes(f);nblignes1=nbrlignes1(f1);nblignes2=nbrlignes2(f2);
    //creation d'une liste chainee de N bus
    for(int k=0;k<nblignes-4;k++){    
    	r=(bus*)malloc(sizeof(bus));
    	r->numbus=k+1;
    	r->dispo=0;
    	r->suivant=l2;
    	l2=r;
    }
	//affichagestructbus(l2);
    printf("1.Administration\n");printf("2.Client\n");printf("3.Sortir\n");
	printf("numero: ");scanf("%d",&x1);
	while(x1!=3){
		if (x1==1){
			printf("Page2------------------------------------------------------------\n");
			printf("(password=0000)\n");printf("Password:");scanf("%d",&PW);
			if(PW==0000){
				administrateur(f,nblignes);
			    printf("Page1------------------------------------------------------------\n");
			    printf("1.Administration\n");printf("2.Client\n");printf("3.Sortir\n");
		        printf("numero: ");scanf("%d",&x1);	
			}
			else{
				printf("Mot De Passe Incorrect\n");printf("Acee Interdit\n");
				printf("Page1------------------------------------------------------------\n");
			    printf("1.Administration\n");printf("2.Client\n");printf("3.Sortir\n");
		        printf("numero: ");scanf("%d",&x1);	
			}
			
		}
	    
		if(x1==2){
			printf("Page2------------------------------------------------------------\n");
			printf("1.log in\n");printf("2.sign in\n");printf("3.retour\n");
			printf("numero: ");scanf("%d",&x2);
			while(x2!=3){
				if(x2==1){
					//fonction pour verifier si il a un compte
					printf("Page3------------------------------------------------------------\n");
					printf("1.Compte\n");printf("2.Reservation\n");printf("3.return\n");
					printf("numero: ");scanf("%d",&x3);
			        while(x3!=3){
			        	if(x3==1){
			        		printf("Page4------------------------------------------------------------\n");
			        		printf("1.Voir Mon Compte\n");printf("2.Modifier Mon Compte\n");printf("3.Supprimer Mon Compte\n");printf("4.return\n");
			        		printf("numero: ");scanf("%d",&x4);
			        		while(x4!=4){
			        			if(x4==1){
			        				//voir mon compte
			        				printf("Page5------------------------------------------------------------\n");
			        				affichagecompteX(l);
			        				fflush(stdin);
			        				printf("Page4------------------------------------------------------------\n");
			        		        printf("1.Voir Mon Compte\n");printf("2.Modifier Mon Compte\n");printf("3.Supprimer Mon Compte\n");printf("4.return\n");
			        		        printf("numero: ");scanf("%d",&x4);
								}
			        			if(x4==2){
			        				//Modifier mon compte
			        				printf("Page5------------------------------------------------------------\n");
			        				printf("Voulez vous modifier\n");printf("1.Nom\n");printf("2.Prenom\n");printf("3.Mail\n");printf("4.phone\n");printf("5.Compte modifiee\n");
			        				printf("Page6------------------------------------------------------------\n");
			        				modifiercompteX(l);
			        				//affichagecompteX(l);
			        				fflush(stdin);
			        				printf("Page4------------------------------------------------------------\n");
			        		        printf("1.Voir Mon Compte\n");printf("2.Modifier Mon Compte\n");printf("3.Supprimer Mon Compte\n");printf("4.return\n");
			        		        printf("numero: ");scanf("%d",&x4);
								}
								if(x4==3){
			        				//Supprimer mon compte
			        				printf("Page4------------------------------------------------------------\n");
			        				int aux2;printf("CIN: ");scanf("%d",&aux2);
			        				l=supprimercomptete(l);
			        				printf("Page4------------------------------------------------------------\n");
			        		        printf("1.Voir Mon Compte\n");printf("2.Modifier Mon Compte\n");printf("3.Supprimer Mon Compte\n");printf("4.return\n");
			        		        printf("numero: ");scanf("%d",&x4);
								}
							}
			        		printf("Page3------------------------------------------------------------\n");
			                printf("1.Compte\n");printf("2.Reservation\n");printf("3.return\n");
		                    printf("numero: ");scanf("%d",&x3);
						}
						if(x3==2){
							printf("Page3------------------------------------------------------------\n");
							afficherlisteaction(f1,nblignes1);//liste d'action
							printf("numero: ");scanf("%d",&x5);
							while(x5!=6){
			        			if(x5==1){
			        				//affichage liste des bus (bien)
			        				printf("Page4------------------------------------------------------------\n");
			        				afficherdescriptionbus(f,nblignes);
			        				printf("-------------------------------------------------------------------------------------------\n");
			        				printf("Page3------------------------------------------------------------\n");
							        afficherlisteaction(f1,nblignes1);//liste d'action
							        printf("numero: ");scanf("%d",&x5);
								}
			        			if(x5==2){
			        				//resrver un bus
			        				printf("Page4------------------------------------------------------------\n");
			        				printf("         Reservation D'un BUS         ");
                                    l1=creationres(l1,nblignes);
                                    fflush(stdin);
                                    int aux=l1->numbus;
                                    //affichagecompteres(l1);
                                    //voir si le bus choisi est disponible ou non
                                    busdispo(aux,l2,l1);
			        				printf("Page3------------------------------------------------------------\n");
							        afficherlisteaction(f1,nblignes1);//liste d'action
							        printf("numero: ");scanf("%d",&x5);
								}
								if(x5==3){
			        				//voir ma reservation
			        				printf("Page4------------------------------------------------------------\n");
			        				printf("         Votre Reservation         ");
			        				affichagereservationX(l1);
			        				fflush(stdin);
			        				printf("Page3------------------------------------------------------------\n");
							        afficherlisteaction(f1,nblignes1);//liste d'action
							        printf("numero: ");scanf("%d",&x5);
								}
								if(x5==4){
			        				//Modifier ma reservation
			        				printf("Page4------------------------------------------------------------\n");
			        				printf("voulez vous modifier\n");
	                                affichermodifresoption(f2,nblignes2);
	                                printf("Page5------------------------------------------------------------\n");
	                                modifierres(l1);
	                                fflush(stdin);
			        				printf("Page3------------------------------------------------------------\n");
							        afficherlisteaction(f1,nblignes1);//liste d'action
							        printf("numero: ");scanf("%d",&x5);
								}
								if(x5==5){
			        				//supprimer ma reservation
			        				printf("Page4------------------------------------------------------------\n");
			        				int aux3;printf("CIN: ");scanf("%d",&aux3);
			        				l1=supprimerestete(l1);
			        				printf("Page3------------------------------------------------------------\n");
							        afficherlisteaction(f1,nblignes1);//liste d'action
							        printf("numero: ");scanf("%d",&x5);
								}
							}
							printf("Page3------------------------------------------------------------\n");
			                printf("1.Compte\n");printf("2.Reservation\n");printf("3.return\n");
		                    printf("numero: ");scanf("%d",&x3);
						}
					}
					printf("Page2------------------------------------------------------------\n");
					printf("1.log in\n");printf("2.sign in\n");printf("3.retour\n");
				    printf("numero: ");scanf("%d",&x2);
				}
				if(x2==2){
					printf("       Creation Du Compte        ");
					l=creationvoy(l);
					printf("##COMPTE CREE\n");
					//affichagecomptevoy(l);
					printf("Page2------------------------------------------------------------\n");
					printf("1.log in\n");printf("2.sign in\n");printf("3.return\n");
				    printf("numero: ");scanf("%d",&x2);
				}
				printf("Page1------------------------------------------------------------\n");
			printf("1.Administration\n");printf("2.Client\n");printf("3.Sortir\n");
		    printf("numero: ");scanf("%d",&x1);	
			
			}
		
		}
	}
   
    
   
    return 0;
}
    



